module.exports.DECRYPT_BASE_URL = "http://127.0.0.1:5000/decrypt";
module.exports.UN_ENC_KEY = "message_key";
module.exports.FILES_DIR = "./files";
