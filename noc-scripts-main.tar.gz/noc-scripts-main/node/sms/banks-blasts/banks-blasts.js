const { DECRYPT_BASE_URL, UN_ENC_KEY, FILES_DIR } = require("./constants");
const { sendGetRequest } = require("../utils/http-requests");
const { getFileFromDir } = require("../utils/dir-operations");
const {
  convertCSVSFileToJSON,
  convertJSONToCSVFile,
} = require("../utils/file-converters");

const decryptMessage = async (message, key) => {
  const url = `${DECRYPT_BASE_URL}/${message}/${key}`;

  const { error, data } = await sendGetRequest(url);
  if (error !== null) throw new Error(`DECRYPTING_ERROR: ${error}`);

  return data.message;
};

const files = getFileFromDir(FILES_DIR);

async function prepareBlastReport(files) {
  if (!(files && Array.isArray(files))) throw new Error("INVALID FILE LIST");

  for (const file of files) {
    console.log("processing report for " + file);

    const blastReport = [];
    const data = convertCSVSFileToJSON(file);

    for (blast of data) {
      const { username, total_sms, message, ekey, sent_date } = blast;
      const sentDate = JSON.stringify(sent_date);

      let msg = message;
      if (ekey !== UN_ENC_KEY) msg = await decryptMessage(message, ekey);

      blastReport.push({
        sent_date: sentDate,
        username,
        total_sms,
        message: msg,
      });
    }
    const filename = `blasts_${file.split("/").pop().split(".")[0]}`;
    convertJSONToCSVFile(blastReport, filename);
    // convertJSONToCSVFile(blastReport, `report_${file}`);
  }
}
prepareBlastReport(files);
// async function fetchMissingDlrs(blast) {
//   const { blastsWithGoodDlr, blastsWithPoorDlr } = separateBlasts(blast);
//   let blastsWithUpdatedDlrs = [];

//   for (let i = 0; i < blastsWithPoorDlr.length; i += 15) {
//     const chunk = blastsWithPoorDlr.slice(i, i + 15);
//     const requestPromises = makePromises(chunk);
//     try {
//       const responses = await Promise.all(requestPromises);
//       const results = responses.map((res, idx) => {
//         const blast = chunk[idx];
//         const dlr = res.DELIVRD?.PERCENTAGE ?? blast.delivery_rate;
//         return { ...blast, delivery_rate: dlr };
//       });
//       blastsWithUpdatedDlrs = [...blastsWithUpdatedDlrs, ...results];
//     } catch (err) {
//       console.log("REQUEST_FAILED", err);
//     }
//   }

//   const allBlasts = [
//     // ...blastsWithGoodDlr,
//     ...blastsWithUpdatedDlrs,
//   ];

//   return allBlasts;
// }

// function makePromises(blasts) {
//   return blasts.map((blast) => {
//     const { bulkId } = blast;
//     const { user, apikey } = createUserAndApiKey(bulkId);
//     console.log("making promise with " + bulkId);
//     return sendRequest(URL, { user, jobid: bulkId, apikey });
//   });
// }

// function separateBlasts(blastsData) {
//   const MINIMUM_PERC = 0;
//   const blastsWithGoodDlr = [];
//   const blastsWithPoorDlr = [];

//   for (idx in blastsData) {
//     const blast = blastsData[idx];
//     const { delivery_rate: dlr } = blast;

//     if (dlr == MINIMUM_PERC) {
//       blastsWithPoorDlr.push({ ...blast, idx });
//     } else {
//       blastsWithGoodDlr.push({ ...blast, idx });
//     }
//   }

//   return { blastsWithGoodDlr, blastsWithPoorDlr };
// }

// fetchMissingDlrs(data).then((res) =>
//   convertJSONToCSVFile(res, "fidelity_2022_zeros.csv")
// );

// const main = convertCSVSFileToJSON("2022_fidelity_blast_report.csv");
// const blastHash = main.reduce((hash, current) => {
//   const cloneHash = { ...hash };
//   const { bulkId } = current;
//   return { ...cloneHash, [bulkId]: current };
// }, {});

// const aux = convertCSVSFileToJSON("fidelity_2022.csv");

// for (const blast of aux) {
//   const { bulkId, delivery_rate } = blast;
//   const matchingBlast = blastHash[bulkId];
//   if (matchingBlast) {
//     blastHash[bulkId] = { ...matchingBlast, delivery_rate };
//   }
// }

// convertJSONToCSVFile(Object.values(blastHash), "updated_fidelity_report.csv");
