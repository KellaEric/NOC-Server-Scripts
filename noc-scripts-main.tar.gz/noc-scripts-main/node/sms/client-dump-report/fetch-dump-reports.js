const path = require("path");
const { sendPostRequest } = require("../utils/http-requests");
const {
  loadFileAsArray,
  convertJSONToCSVFile,
} = require("../utils/file-converters");

const JOBIDS_FILE_PATH = "jobids.txt";
const URL = "https://logs.nalosolutions.com/dumpreport/jobid/report.php";

// curl --location --request POST 'https://logs.nalosolutions.com/dumpreport/jobid/report.php' \
// --header 'Content-Type: application/json' \
// --data '{
// "jobid":"pers.0017144.20230217.0001765"
// }'

//  chunkResponse: [
//    {
//      status: 200,
//      message: "enjoy",
//      id: "",
//      path: "https://logs.nalosolutions.com/dumpreport/jobid/smslogs/pers.0017144.20230217.0001765.csv",
//    },
//    {
//      status: 200,
//      message: "enjoy",
//      id: "",
//      path: "https://logs.nalosolutions.com/dumpreport/jobid/smslogs/pers.0017144.20230217.0001765.csv",
//    },
//  ];

const getSentDate = (path) => {
  const jobid = path.split("/").pop();
  const dateString = jobid.split(".")[2];
  const year = dateString.substring(0, 4);
  const month = dateString.substring(4, 6);
  const day = dateString.substring(6, 8);

  return `${year}-${month}-${day}`;
};

function getChunks(arr) {
  const chunks = [];
  const chunkSize = 5;
  let offset = 0;

  while (arr.length > offset) {
    const pointer = offset + chunkSize;
    const chunk = arr.slice(offset, pointer);

    offset = pointer;
    chunks.push(chunk);
  }

  return chunks;
}

const jobids = loadFileAsArray(path.join(__dirname, JOBIDS_FILE_PATH));

async function fetchDumpReports(jobids) {
  const reportUrls = [];
  const chunks = getChunks(jobids);

  for (const chunk of chunks) {
    const chunkPromise = chunk.map((jobid) => sendPostRequest(URL, { jobid }));
    const chunkResponse = await Promise.all(chunkPromise);

    chunkResponse.forEach((res) => {
      if (res.err) return console.log(`ERROR_FETCHING::: ${res.err.message}`);
      if (!res.path) return console.log("NO_REPORT_FOUND");

      reportUrls.push({
        sent_date: getSentDate(res.path),
        download_url: res.path,
      });
    });
  }

  convertJSONToCSVFile(reportUrls, "jobids_dump.csv");
}

fetchDumpReports(jobids);
