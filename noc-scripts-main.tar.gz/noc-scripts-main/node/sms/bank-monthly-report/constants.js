const SENT_DIR_NAME = "etranzact/sent_files";
const DLRS_DIR_NAME = "etranzact/stat_files";
const ACK_STATUS = "EXPIRED";
const ACK_DELIVERED_DATE = null;
const REPORT_NAME_PREFIX = "etranzact";

const NETWORKS = {
  expresso: { name: "EXPRESS0", prefix: "23328" },
  vodafone: { name: "VODAFONE", prefix: "23350|23320" },
  mtn: {
    name: "MTN",
    prefix: "23324|23325|23359|23355|23354|23359|23353",
  },
  airteltigo: {
    name: "AIRTELTIGO",
    prefix: "23327|23357|23326|23356|23323",
  },
};

module.exports = {
  SENT_DIR_NAME,
  DLRS_DIR_NAME,
  ACK_STATUS,
  ACK_DELIVERED_DATE,
  REPORT_NAME_PREFIX,
  NETWORKS,
};

// 03|04|10|11|17|18|24|25|28|
