const {
  convertJSONToCSVFile,
  loadFileAsArray,
} = require("../utils/file-converters");
const { getFileFromDir } = require("../utils/dir-operations");
const { getUniqueKey, makeObjectHash, getExpiredDate } = require("./utils");
const {
  SENT_DIR_NAME,
  DLRS_DIR_NAME,
  ACK_STATUS,
  REPORT_NAME_PREFIX,
} = require("./constants");

function getAllReports(sentDir, dlrDir) {
  const sentFilenames = getFileFromDir(sentDir);
  const dlrFilenames = getFileFromDir(dlrDir);

  let total = 0;
  const networkReport = {};

  for (let sentFilename of sentFilenames) {
    console.log(`working on file ${sentFilename} `);
    const key = getUniqueKey(sentFilename);
    const dlrFilename = dlrFilenames.find(
      (filename) => getUniqueKey(filename) === key
    );
    // console.log({ key, sentFilename, dlrFilename });
    [totalSMS, netreport] = generateReport(sentFilename, dlrFilename, key);
    total += totalSMS;

    for (let key in netreport) {
      const previousCount = networkReport[key] ?? 0;
      networkReport[key] = previousCount + netreport[key];
    }

    console.log({ CURRENT_TOTAL_SENT: total, ...networkReport });
  }
}

function generateReport(sentFilename, dlrFilename, name) {
  const sentLogs = loadFileAsArray(sentFilename);
  const dlrsLogs = loadFileAsArray(dlrFilename);

  const networkCounts = {};

  const sentObjectHash = makeObjectHash(sentLogs, "sent");
  const dlrsObjectHash = makeObjectHash(dlrsLogs);

  const report = [];

  for (key of Object.keys(sentObjectHash)) {
    const sms = sentObjectHash[key];
    const dlr = dlrsObjectHash[sms.fid];

    const { network, pageCount } = sms;
    const networkCount = networkCounts[network] ?? 0;
    networkCounts[network] = networkCount + pageCount;

    const record = {
      sent_date: sms.sentAt,
      sender: sms.sender,
      msisdn: sms.msisdn,
      network: sms.network,
      message: sms.message,
      page_count: sms.pageCount,
      status: dlr?.status ?? ACK_STATUS,
      delivered_date: dlr?.deliveredAt ?? getExpiredDate(sms.sentAt),
    };

    report.push(record);
    // console.log(record);
  }

  // console.log(report);
  convertJSONToCSVFile(report, `${REPORT_NAME_PREFIX}_${name}`);
  return [report.length, networkCounts];
}

getAllReports(SENT_DIR_NAME, DLRS_DIR_NAME);
