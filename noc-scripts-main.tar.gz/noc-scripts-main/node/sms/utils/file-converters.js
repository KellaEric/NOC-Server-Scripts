const fs = require("fs");
const xlsx = require("xlsx");

function loadFileAsArray(filename) {
  console.log({ filename });
  const content = fs.readFileSync(filename, "utf-8");
  const data = content.split("\n");
  return data;
}

const convertCSVSFileToJSON = (csvFile) => {
  const csvWorkBook = xlsx.readFile(csvFile, { cellDates: true });
  const sheet = csvWorkBook.SheetNames[0];
  const csvSheet = csvWorkBook.Sheets[sheet];
  return xlsx.utils.sheet_to_json(csvSheet);
};

const createCsvFile = (data, sheetname) => {
  try {
    const filename = sheetname + ".csv";
    const newWkBk = xlsx.utils.book_new();
    const newSheet = xlsx.utils.json_to_sheet(data);
    xlsx.utils.book_append_sheet(newWkBk, newSheet, sheetname);
    xlsx.writeFile(newWkBk, filename);
    console.log("file created sucessfully", filename);
  } catch (err) {
    console.log("AN ERROR OCCURED" + err);
  }
};

const convertJSONToCSVFile = (jsonData, sheetname) => {
  const ROW_LIMIT = 800_000;
  let postfix = "";

  for (let i = 0; i < jsonData.length; i += ROW_LIMIT) {
    const data = jsonData.slice(i, i + ROW_LIMIT);
    createCsvFile(data, sheetname + postfix);
    postfix = i === 0 ? "_1" : `${+postfix++}`;
  }
};

module.exports = {
  convertCSVSFileToJSON,
  convertJSONToCSVFile,
  loadFileAsArray,
};
