const axios = require("axios");

async function sendPostRequest(url, payload) {
  try {
    const res = await axios.post(url, payload);
    return { err: null, data: res.data };
  } catch (err) {
    return { err: err.response?.data || err };
  }
}

async function sendGetRequest(url) {
  try {
    const res = await axios.get(url);
    return { error: null, data: res.data };
  } catch (error) {
    return { error, data: null };
  }
}
module.exports = { sendPostRequest, sendGetRequest };
