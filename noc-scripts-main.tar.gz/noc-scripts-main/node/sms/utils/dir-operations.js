const fs = require("fs");

function getFileFromDir(dir) {
  try {
    const files = fs.readdirSync(dir);
    return files.map((file) => `${dir}/${file}`);
  } catch (err) {
    return console.log("ERROR_GETTING_FILE_LIST", err.message);
  }
}

module.exports = { getFileFromDir };
