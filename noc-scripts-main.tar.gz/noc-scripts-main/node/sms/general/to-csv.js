const {
  convertJSONToCSVFile,
  loadFileAsArray,
} = require("../utils/file-converters");

const filename = "fidelity_undeliv_techuser.txt";

const data = loadFileAsArray(filename);
const report = data.map((line) => {
  [msisdn, error] = line.split(" ");
  return { date: "2023-07", msisdn, error };
});

convertJSONToCSVFile(report, "fidelity_undeliv_numbers_blast");
