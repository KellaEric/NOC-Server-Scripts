const fs = require("fs");

async function createFile(numbers) {
  const logStream = fs.createWriteStream("blast_two_12.txt", { flags: "a" });

  for (number of numbers) {
    logStream.write(`${number}\n`, (err) => {
      if (err) throw err;
    });
  }

  logStream.end();
}

function loadFileAsArray(filename) {
  console.log({ filename });
  const content = fs.readFileSync(filename, "utf-8");
  const data = content.split("],");
  const contacts = data.map((element) => {
    element = element.replace("/[/g", "");
    const idx = element.indexOf("'233");
    const sample = element.substring(idx, 16);
    return sample.trim().replace(/'/g, "");
  });

  return contacts;
}

async function doword() {
  const contacts = loadFileAsArray("blast_sent_12.txt");
  await createFile(contacts);
}

doword();
