const RESELLER_USERIDS = [
  { name: "Fidelity_Resl_fidelitybank_api", resellerUserid: "0020173" },
  { name: "Etrans_Resl_etranz12345", resellerUserid: "0139804" },
  { name: "Etrans_Resl_etranzi", resellerUserid: "0139772" },
  { name: "Telos_Resl_AsaSMS", resellerUserid: "0035932" },
  { name: "Telos_Resl_Asasms2", resellerUserid: "0357599" },
  { name: "Telos_Resl_AsaOTP", resellerUserid: "3510127" },
  { name: "Resl_Prud_prudentialbankgh", resellerUserid: "0638363" },
  { name: "Resl_Prud_prudentialblast", resellerUserid: "0639771" },
  { name: "RepBank_Resl_hfcOTP", resellerUserid: "0078947" },
  { name: "RepBank_Resl_hfc", resellerUserid: "0071555" },
  { name: "RepBank_Resl_reptrust", resellerUserid: "0077986" },

  /* 
NO RECORD(S) FOUND FOR USER 0139772
NO RECORD(S) FOUND FOR USER 0000383
NO RECORD(S) FOUND FOR USER 0010113
NO RECORD(S) FOUND FOR USER 0036979
NO RECORD(S) FOUND FOR USER 0000021
NO RECORD(S) FOUND FOR USER 0021597


*/
  // fetch these from s3
  // { name: "Resl_Nalo_na1-atc", resellerUserid: "0033686" },
  // { name: "Resl_Nalo_usrinvendis", resellerUserid: "0036444" },
  // { name: "Resl_Nalo_na1-FABL", resellerUserid: "0000383" },
  // { name: "FAB_Resl_FABL", resellerUserid: "0001090" },
  // { name: "FAB_Resl_na1-fabl", resellerUserid: "0010113" },
  // { name: "FAB_Resl_na1-fabltd", resellerUserid: "0010114" },
  // { name: "BOA_Resl_boafrica", resellerUserid: "0011117" },
  // { name: "Resl_Nalo_boafrica", resellerUserid: "0036979" },
  // { name: "Cell_resl_stargroupapp", resellerUserid: "0002121" },
  // { name: "Cell_resl_cellulantPortalUser", resellerUserid: "0000021" },
  // { name: "Cell_resl_Rohi_Chapel", resellerUserid: "0021597" },
  // { name: "Resl_Nalo_JSO", resellerUserid: "0035021" },
  // { name: "Sipisoft_Resl_nic", resellerUserid: "0036926" },
  // { name: "Resl_GTBank_gtbankOtp", resellerUserid: "0879543" },
  // { name: "Resl_GTBank_gtbankGens", resellerUserid: "0879671" },
  // { name: "RepBank_Resl_rep", resellerUserid: "0077986" },
  // { name: "na1-ubaghana", resellerUserid: "" },
  // { name: "Perez_Resl_pcidzorwulu", resellerUserid: "" },
  // { name: "hfc", resellerUserid: "" },
  // { name: "hfcOTP", resellerUserid: "" },
  // { name: "Resl_Nalo_ElijahWachu", resellerUserid: "" },
  // { name: "SokoC_Resl_ElijahWachu", resellerUserid: "" },
  // { name: "Resl_Prud_prudentialbank", resellerUserid: "" },
  // { name: "etranzact", resellerUserid: "" },
  // { name: "na1-ecobank", resellerUserid: "" },
  // { name: "Eco_Resl_na1-ecobank", resellerUserid: "" },
];

const START_DATE = "2023-07-01";
const END_DATE = "2023-07-31";
const URL = "https://logs.nalosolutions.com/netreport/";

module.exports = { RESELLER_USERIDS, START_DATE, END_DATE, URL };
