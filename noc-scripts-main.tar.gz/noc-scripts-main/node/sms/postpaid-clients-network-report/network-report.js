const { RESELLER_USERIDS, START_DATE, END_DATE, URL } = require("./constants");
const { sendPostRequest } = require("../utils/http-requests");
const { convertJSONToCSVFile } = require("../utils/file-converters");

const NO_RECORD_FOUND = "NO RECORD(S) FOUND FOR USER";

async function fetchUserNetworkReport(userid) {
  console.log(`fetching network report for user:${userid}`);

  const { err, data } = await sendPostRequest(URL, {
    user: userid,
    start_date: START_DATE,
    end_date: END_DATE,
  });
  if (err !== null) {
    console.error(`FETCH FAILED FOR user:${userid}`);
    console.error(`FETCH_ERROR: ${err}`);
    return [];
  }
  if (data.status === NO_RECORD_FOUND) {
    console.log(data.status, userid);
    return [];
  }
  return data;
}

async function getPostpaidUsersNetworkReports(users) {
  let reports = [];

  for (const user of users) {
    if (!user) return console.log("INVALID USER DATA");

    const { name, resellerUserid: userid } = user;
    const data = await fetchUserNetworkReport(userid);

    const userReport = data.map((record) => ({ username: name, ...record }));
    console.log(userReport);
    reports = reports.concat(userReport);
  }

  convertJSONToCSVFile(reports, `network-report_${START_DATE}.csv`);
}

getPostpaidUsersNetworkReports(RESELLER_USERIDS);
