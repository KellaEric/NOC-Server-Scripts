# === DESCRIPTION ===

This is a the health check script

# === HOW TO RUN ===

-> Update the username in the constants.py file
-> For the SERVER_DETAILS dictionary in constants.py, you can remove the details of the server you don't have accounts on.

NB: You will have to enter your password for each server if you haven't configured ssh login with public key
