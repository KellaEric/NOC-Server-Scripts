# change this to your username
USERNAME = "ekmwinwule"
DISK_DIRS = ['/', '/home', '/run', '/boot']

SMSC_NAMES = ['tigo2', 'tigo','scairt', 'nalmtn', 'nalvoda']

SERVER_DETAILS = {"5.9.79.123": "945","136.243.56.160": "945", "159.69.65.95": "1610"}

INTERVALS = (
    ('weeks', 604800),  # 60 * 60 * 24 * 7
    ('days', 86400),    # 60 * 60 * 24
    ('hours', 3600),    # 60 * 60
    ('minutes', 60),
    ('seconds', 1),
)
