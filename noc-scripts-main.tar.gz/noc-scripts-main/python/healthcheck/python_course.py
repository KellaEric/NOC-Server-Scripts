# Exercises: Variables, Operators, Strings
# THECODEX EXERCISES - Variables, Operators, Strings (Available for download down below) 



# 1. Write a script that adds 15 and 30 and divides the sum by 2. Print out the answer.

# 2. Initialize two variables and use arithmetic operators to add, subtract, multiply, divide, and find the remainder.

# 3. Create a variable called name and store your name in it as a string.

# 4. Create three variables in one line and assign each one a different food item.

# 5. Print out "Hello" ten times using arithmetic operators.

# 6. Set your name and age variables in one line with multiple assignment

# 7. Create two strings and then create a third variable combining both of the two original strings.

# 8. Create a string and print the fourth letter of the word.

# 9. Create a string and print the letters from index 0 to 5.

# 10. Create a variable and print all the letters from the first index until the end.
# # Task 1
# # result = (15 + 30) / 2
# # print(result)


# Ro the other way to write this code
# number= (15+10)/2
# output= number 
# print(float(output))


# # Task 2
# a = 10
# b = 5
# addition_result = a + b
# subtraction_result = a - b
# multiplication_result = a * b
# division_result = a / b
# remainder_result = a % b

# print(f"Addition: {addition_result}")
# print(f"Subtraction: {subtraction_result}")
# print(f"Multiplication: {multiplication_result}")
# print(f"Division: {division_result}")
# print(f"Remainder: {remainder_result}")


# # Task 3
# name = "YourName"

# #Task 4
# Kela, Richard, Kwame = "24 years old \n", " 22 years of Age \n", " the youngest of 18"
# print(Kela,Richard)

# #Task 5
# print('Eric \n ' * 10 )
# name, age= "Your name", 20
# print(name,age)

# # Task 7
# string1 = "Hello"
# string2 = "World"
# combined_string = string1 + " " + string2
# print(combined_string)

# # Task 8
# variable=" Welcometotheworld"
# print(variable[4]) 

# #Task 9

# # slicing in python 
# sl= " banku, Emo, Bayere"
# print(sl[0:5])

# #Task 10 
# my_var= " Welcometopytoncourse"
# print(my_var[1:])

# Introduction to python lists.
# players=['Ronaldo', 'Messi', 'Mbape', 'Haland']
# print(players[0:4])

# #appending names to players
# players.append('Ericson')
# print(players)
# print(players)
# # Updating players by removing names from the list
# del players[3]
# print(players)
 
# # maximize and minimixe list
# creater=[30,1,34,100,35,22,10]
# print(min(creater))

# print(max(creater))
# print (players +creater)

# Dictionary
database={'books':1,'Website': 2, 'students': 3, 'teachers':4}
print(database['teachers'])
del database["Website"]
print(database)


# Turples
#"Turples are imutable in python. Just like other programminh languages like java, C++ etc using arrays."
# tuple= (1,3,4,5,6,7)

# print(tuple)
# print(tuple[2])

# tuple2 =tuple[3]+tuple[2]
# print(tuple2)

# Try and Except: this block is  is used in a situation where exceptions may be arise

# Implementation
name= 45
try:
    if name <10:
        print('you are under aged')
except:
    print ( ' this cannot be possible')
    
    
# Functions in python 
# implementation 
def hello(name):
    print(name+ " welcome the  Nalo !")

hello("Eric")

