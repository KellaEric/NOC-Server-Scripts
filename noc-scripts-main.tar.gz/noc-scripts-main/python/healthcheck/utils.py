from constants import INTERVALS, DISK_DIRS


def disk_space_stat(cmd):
    output = cmd[0].decode("utf-8")
    dstring = output.split('\n')
    server_namee = dstring[0]
    print(
        f"\n=======================\n\t{server_namee}\n=======================")
    all_arr = []
    mem_list = []
    mem_total = 0.0
    m_used = 0.0
    m_available = 0.0
    swap_list = []
    swap_total = 0.0
    s_used = 0.0
    s_free = 0.0
    for i in dstring:
        if "Mem" in i:
            mem_list = i.split()
            mem_total = float(mem_list[1])
            m_used = float(mem_list[2])/mem_total
            m_available = float(mem_list[6])/mem_total
        if "Swap" in i:
            swap_list = i.split()
            swap_total = float(swap_list[1])
            if swap_total != 0.0:
                s_used = float(swap_list[2])/swap_total
                s_free = float(swap_list[3])/swap_total
        all_arr.append(i.split())

    for i in all_arr:
        try:
            name = i[-1:][0]
            percentage = i[-2:-1][0]
            fmt = f"{name:<12} - {percentage}"
            if name in DISK_DIRS:
                print(fmt)
        except IndexError:
            pass
        except:
            print("Something else went wrong")

    # print(f"{'SMSC NAME':<20}{name.upper()}")
    mem_used = "{:.2f}".format(m_used*100)
    mem_available = "{:.2f}".format(m_available*100)
    swap_used = "{:.2f}".format(s_used*100)
    swap_free = "{:.2f}".format(s_free*100)
    print(f"{'Mem Used :':<15}{mem_used+'%' :<20}{'Swap Used : ':<15}{swap_used+'%'}")
    print(f"{'Mem Avail:':<15}{mem_available+'%':<20}{'Swap Avail: ':<15}{swap_free+'%'}")
    print(dstring[len(dstring)-2].strip())


def display_time(seconds, granularity=3):
    result = []

    for name, count in INTERVALS:
        value = seconds // count
        if value:
            seconds -= value * count
            if value == 1:
                name = name.rstrip('s')
            result.append("{} {}".format(value, name))
    return ', '.join(result[:granularity])


def smsc_uptime(name, cmd):
    output = cmd[0].decode("utf-8")
    dstring = output.split('\n')
    m_list = []
    online = 0
    re_con = 0
    dead = 0
    for i in dstring:
        item = i.split(" - ")
        if len(item) > 1:
            temp_dict = {"status": item[0],
                         "uptime": item[1], "uptime_readable": ""}
            if temp_dict["status"] == "online":
                online += 1
                uptime_readable = display_time(int(temp_dict["uptime"]))
                temp_dict["uptime_readable"] = uptime_readable
            elif temp_dict["status"] == "re-con":
                re_con += 1
            else:
                dead += 1

            m_list.append(temp_dict)
    print(
        f"\n===========================\n\tSMSC UPTIME\n===========================")
    print("\tSUMMARY:")
    print(f"{'SMSC NAME':<20}{name.upper()}")
    print(f"{'ONLINE':<20}{online}")
    print(f"{'RE-CONNECTING':<20}{re_con}")
    print(f"{'DEAD':<20}{dead}")
    print(f"{'TOTAL BINDS':<20}{len(m_list)}")
    print("\tBREAKDOWN:")
    fin_list = sorted(m_list, key=lambda k: k['uptime_readable'])
    for i in fin_list:
        print(
            f"{'Status:':<10}{i['status']:<10}{'Uptime:':<10}{i['uptime_readable']}")
