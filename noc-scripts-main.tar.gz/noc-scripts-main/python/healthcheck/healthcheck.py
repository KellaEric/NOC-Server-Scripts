import subprocess
from constants import USERNAME, SMSC_NAMES, SERVER_DETAILS
from utils import disk_space_stat, smsc_uptime


commands = "cat begin;df -h;free -m;uptime"
for item in SERVER_DETAILS.items():
    cmd = subprocess.Popen(f"ssh {USERNAME}@{item[0]} -p{item[1]} '{commands}'",
                           shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
    disk_space_stat(cmd)


for name in SMSC_NAMES:
    lenght = len(name)
    a = f"/etc/init.d/kannel-bearerbox fullstatus |grep -w {name} |"
    b = "awk '{ print substr($3,2,6)\" - \" $4 "
    c = "}' | awk -F \"s,\" '{print $1}'"
    query = a + b + c
    ip = "5.9.79.123"
    port = "945"
    
    # Server 7 ip address and port number
    ip= "159.69.65.95"
    port= 1610
    
    cmd = subprocess.Popen(
        f"ssh {USERNAME}@{ip} -p{port} {query}", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
    smsc_uptime(name, cmd)

print("\n===========================\n\tATC SERVER\n===========================")
print("Sending API Request to Acys SMS Gateway...")
query = 'curl "https://sms.nalosolutions.com/smsbackend/clientapi/Resl_Nalo/send-message/?username=lmensah_test&password=lmensah_test&type=0&dlr=1&destination=233267777788&source=Test&message=test"'
cmd = subprocess.Popen(
    f"{query}", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
cmd = subprocess.Popen(
    f"{query}", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()

print("DONE!!! \nCOMFIRM RESPONSE FROM THE PORTAL")

#
