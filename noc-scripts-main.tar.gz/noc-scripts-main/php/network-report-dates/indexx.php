<?php
    $dates = json_decode(file_get_contents("dates.json"), true);
    $dir = "/opt/kannel/var/log";

    foreach ($dates as $key=>$value) {
        $month = trim($value['date']);
        $monthDatePlus = date('Y-m-d', strtotime($month.'01' . ' +1 month'));

        shell_exec("mkdir $month");
        $voda = "to:23350|to:23320";
        $mtn = "to:23324|to:23325|to:23359|to:23355|to:23354";
        $airteltigo = "to:23327|to:23357|to:23326|to:23356";
        $expresso = "to:23328";
        $glo = "to:23323";
        $unknown = "$voda|$mtn|$airteltigo|$expresso|$glo";
        $networkArray = array("voda"=>$voda,"mtn"=>$mtn,"airteltigo"=>$airteltigo,"expresso"=>$expresso,"glo"=>$glo, "unknown"=>$unknown);
        $cmd = "zcat $dir/access_server.log-$month* $dir/access_server.log-$monthDatePlus"."_00\:00.gz | grep apiuser | grep 'Sent SMS' | grep Fidelity_Resl_fidelitybank_api  | grep '^$month' > $month/temp.log";
        echo $cmd.PHP_EOL.PHP_EOL;
        shell_exec($cmd);
        foreach ($networkArray as $key=>$value) {
            $cmd = "";
            if($key=="unknown"){
                $cmd = "cat $month/temp.log |egrep -v \"$value\"";
                $cmd = $cmd." | awk -F 'msg:' '{print \$2}' | awk -F ':' '{print \$1 \",\"}' > $month/$key.txt";   
            }else{
                $cmd = "cat $month/temp.log |egrep \"$value\"";
                $cmd = $cmd." | awk -F 'msg:' '{print \$2}' | awk -F ':' '{print \$1 \",\"}' > $month/$key.txt";
            }
            shell_exec($cmd);
            echo $cmd.PHP_EOL.PHP_EOL;
            // pick the file and work it

            $counts = file_get_contents("$month/$key.txt");
            $counts_array = explode(',',$counts);
            $page_count = 0; 
           foreach($counts_array as $pages){
                if($pages > 0 && $pages <= 160) {
                    $page_count = '1';
                }elseif($pages > 160 && $pages <= 306) {
                    $page_count = '2';
                }elseif($pages > 306 && $pages <= 459){
                    $page_count = '3';
                }elseif($pages > 459 && $pages <= 621){
                    $page_count = '4';
                }elseif($pages > 621 && $pages <= 766){
                    $page_count = '5';
                }elseif($pages > 766){
                    $page_count = '6';
                }
                file_put_contents("$month/file_$key.csv", $pages.','.$page_count,FILE_APPEND);
                $page_count = 0;
            }

            $count = shell_exec("cat $month/file_$key.csv | wc -l");
            $sms_page_sum = shell_exec("awk -F ',' '{sum+=\$2;} END{print sum;}' $month/file_$key.csv");
            file_put_contents("$month/$month.txt", "$key: Count:".trim($count)." Sum: ".trim($sms_page_sum).PHP_EOL, FILE_APPEND);
        }
    }
    
?>

