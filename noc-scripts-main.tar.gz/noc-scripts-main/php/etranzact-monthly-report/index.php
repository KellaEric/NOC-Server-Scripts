<?php
// Set the timezone to your desired location
date_default_timezone_set('America/New_York');

$dir = '/opt/kannel/var/log';

//get all senders for the month and update this list
$senders = 'from:UG_LEGON|from:AIS|from:BestMobile|from:BMobile|from:NIB|from:eTranzact|from:JUSTPAY|from:GCBMobile||from:AbiNational|from:BOAPAY|from:ETZOVAM|from:Etz|from:KGL|from:PALMPAY|from:SISL|from:SekoBank|from:TREE|from:etranzact'

//change this to the previous month
$month = 7;
$year = date('Y'); 
$num_days = cal_days_in_month(CAL_GREGORIAN, $month, $year); 

for ($day = 1; $day <= $num_days; $day++) {
    $sent_date = date('Y-m-d', strtotime("$year-$month-$day"));
    $next_date = date('Y-m-d', strtotime($sent_date . ' +1 day'));
    $submit_date = substr(date('Ymd', strtotime($sent_date)), 2);

    $command_sent = "zcat $dir/access_server.log-$sent_date* $dir/access_server.log-$next_date* | grep $sent_date | grep ACT:Etrans_Resl_etranz12345 > ~/etranzact/sent_files/sent_log_$submit_date.txt";
    $command_stat = "zcat $dir/access_server.log-$sent_date* $dir/access_server.log-$next_date* | grep apiuser | egrep $senders | grep stat: | grep 'submit date:$submit_date' | gawk '{print \$1,\$2,\$9,\$22}' > ~/etranzact/stat_files/stat_log_$submit_date.txt";

   echo $command_sent.PHP_EOL.PHP_EOL;
   shell_exec($command_sent);

    echo $command_stat.PHP_EOL.PHP_EOL;
    shell_exec($command_stat);

    // shell_exec($command_sent);
    // shell_exec($command_stat);

}


?>