<?php
    $accounts = json_decode(file_get_contents("accounts.json"), true);
    $sentDate = "2023-03";
    $sentDatePlus = "2023-04-01";
    foreach ($accounts as $key=>$account) {
        $accountName = trim($account['name']);
        echo $accountName;
        shell_exec("mkdir $accountName");
        $voda = "to:23350|to:23320";
        $mtn = "to:23324|to:23325|to:23359|to:23355|to:23354";
        $airteltigo = "to:23327|to:23357|to:23326|to:23356";
        $expresso = "to:23328";
        $glo = "to:23323";
        $unknown = "$voda|$mtn|$airteltigo|$expresso|$glo";
        $networkArray = array("voda"=>$voda,"mtn"=>$mtn,"airteltigo"=>$airteltigo,"expresso"=>$expresso,"glo"=>$glo, "unknown"=>$unknown);
        $cmd = "zcat /opt/kannel/var/log/access_server.log-$sentDate* /opt/kannel/var/log/access_server.log-$sentDatePlus"."_00\:00.gz |grep apiuser | grep 'Sent SMS'|grep -w $accountName | grep '^$sentDate' > $accountName/temp.log";
        echo $cmd.PHP_EOL;       
        shell_exec($cmd);
        foreach ($networkArray as $key=>$value) {
            $cmd = "";
            if($key=="unknown"){
                $cmd = "cat $accountName/temp.log |egrep -v \"$value\"";
                $cmd = $cmd." | awk -F 'msg:' '{print \$2}' | awk -F ':' '{print \$1 \",\"}' > $accountName/$key.txt";
            }else{
                $cmd = "cat $accountName/temp.log |egrep \"$value\"";
                $cmd = $cmd." | awk -F 'msg:' '{print \$2}' | awk -F ':' '{print \$1 \",\"}' > $accountName/$key.txt";
            }
            shell_exec($cmd);
            echo $cmd.PHP_EOL.PHP_EOL;
            // pick the file and work it

            $counts = file_get_contents("$accountName/$key.txt");
            $counts_array = explode(',',$counts);
                $page_count = 0;
           foreach($counts_array as $pages){
                if($pages > 0 && $pages <= 160) {
                    $page_count = '1';
                }elseif($pages > 160 && $pages <= 306) {
                    $page_count = '2';
                }elseif($pages > 306 && $pages <= 459){
                    $page_count = '3';
                }elseif($pages > 459 && $pages <= 621){
                    $page_count = '4';
                }elseif($pages > 621 && $pages <= 766){
                    $page_count = '5';
                }elseif($pages > 766){
                    $page_count = '6';
                }
                file_put_contents("$accountName/file_$key.csv", $pages.','.$page_count,FILE_APPEND);
                $page_count = 0;
            }

            $count = shell_exec("cat $accountName/file_$key.csv | wc -l");
            $sms_page_sum = shell_exec("awk -F ',' '{sum+=\$2;} END{print sum;}' $accountName/file_$key.csv");
            file_put_contents("$accountName/$accountName.txt", "$key: Count:".trim($count)." Sum: ".trim($sms_page_sum).PHP_EOL, FILE_APPEND);
        }
    }

?>
