# noc-scripts
This will contain scripts for performing some noc tasks

# Your contribution
Follow these steps to contribute

  ->  DO NOT PUSH TO MAIN BRANCH
  
  -> create a branch with a name same as your username, eg lmensah
  
  -> push your code there and a create a PR
  
  -> Other members will review your code and merge with the main branch if it's fine.
  
  -> Should you refactor or fix a bug in someone's code, create a branch with naming format below
  
    * refactor : your_username/refactor/script_name
    
    * bug fix : your_username/bugix/script_name
    
  -> Create a PR
  
  -> The branch will be deleted after review and merging with main
